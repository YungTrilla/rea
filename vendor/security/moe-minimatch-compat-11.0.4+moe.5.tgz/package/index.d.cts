import type * as Core from '@moe/minimatch-core';
interface LegacyExpression {
  test(input: string): boolean;
  [Symbol.match](input: string): RegExpMatchArray | null;
}
declare class LegacyMinimatch extends Core.Minimatch {
  makeRe(): LegacyExpression;
}
declare const minimatch: typeof Core.minimatch & Omit<typeof Core, 'Minimatch'> & {
  Minimatch: typeof LegacyMinimatch;
  makeRe(pattern: string, options?: Core.MinimatchOptions): LegacyExpression;
};
export = minimatch;
