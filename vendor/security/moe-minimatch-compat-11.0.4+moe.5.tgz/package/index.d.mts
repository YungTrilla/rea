export * from '@moe/minimatch-core';
import type * as Core from '@moe/minimatch-core';
export interface LegacyExpression {
  test(input: string): boolean;
  [Symbol.match](input: string): RegExpMatchArray | null;
}
export declare class Minimatch extends Core.Minimatch {
  makeRe(): LegacyExpression;
}
export declare function makeRe(pattern: string, options?: Core.MinimatchOptions): LegacyExpression;
declare const minimatch: typeof Core.minimatch & Omit<typeof Core, 'Minimatch'> & {
  Minimatch: typeof Minimatch;
  makeRe: typeof makeRe;
};
export default minimatch;
