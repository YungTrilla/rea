'use strict';
const core = require('@moe/minimatch-core');
const compatibility = Object.assign(core.minimatch, core);
// Preserve an intact core instance for whole-path matching. The legacy public
// rows below belong to glob7; replacing them must not invalidate core caches.
function legacyExpression(matcher) {
  return {
    test(input) { return matcher.match(String(input)); },
    [Symbol.match](value) {
      const input = String(value);
      return this.test(input) ? Object.assign([input], { index: 0, input }) : null;
    },
  };
}
// glob7 consumes RegExp's String.match protocol and _glob, but the patched
// core deliberately uses nonrecursive Matcher objects. Delegate to their test
// method: never rebuild a regex from the glob or from Matcher's debug string.
function legacyPart(part) {
  if (typeof part === 'string' || part === core.GLOBSTAR || part[Symbol.match]) return part;
  Object.defineProperties(part, {
    _glob: { value: part.pattern },
    [Symbol.match]: { value(value) {
      const input = String(value);
      return this.test(input) ? Object.assign([input], { index: 0, input }) : null;
    } },
  });
  return part;
}
compatibility.Minimatch = class Minimatch extends core.Minimatch {
  #whole;
  constructor(pattern, options = {}) {
    super(pattern, { ...options, optimizationLevel: 0 });
    this.#whole = new core.Minimatch(pattern, this.options);
    // Core merges brace-expanded rows even at optimizationLevel0. glob7's
    // nonull path needs one row for each original globSet entry. Compile each
    // already-expanded alternative with the unchanged patched core, preserving
    // its validation, expansion bounds and nonrecursive matching engine.
    if (!this.comment && !this.empty) {
      const globSet = [], globParts = [], set = [];
      for (const glob of this.globSet) {
        const single = new core.Minimatch(glob, {
          ...this.options, nobrace: true, nonegate: true, nocomment: true,
          optimizationLevel: 0,
        });
        if (!single.set.length) continue;
        globSet.push(glob);
        globParts.push(single.globParts[0]);
        set.push(single.set[0].map(legacyPart));
      }
      this.globSet = globSet;
      this.globParts = globParts;
      this.set = set;
    }
  }
  match(input, partial) { return this.#whole.match(input, partial); }
  makeRe() { return legacyExpression(this.#whole); }
};
// The installed import plugin uses only .test(). Keep the bounded, nonrecursive
// matcher rather than generating a RegExp from attacker-controlled patterns.
compatibility.makeRe = (pattern, options) => legacyExpression(new core.Minimatch(pattern, options));
module.exports = compatibility;
