import compatibility from './index.cjs';
export default compatibility;
export const { minimatch, Minimatch, GLOBSTAR, sep, filter, defaults,
  braceExpand, match, makeRe, escape, unescape, AST } = compatibility;
