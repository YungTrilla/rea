import { FileIntegrity } from './integrity.js';
import { CrawledFileType } from './crawlfs.js';
export type EntryMetadata = {
    unpacked?: boolean;
};
export type FilesystemDirectoryEntry = {
    files: Record<string, FilesystemEntry>;
} & EntryMetadata;
export type FilesystemFileEntry = {
    unpacked: boolean;
    executable: boolean;
    offset: string;
    size: number;
    integrity: FileIntegrity;
} & EntryMetadata;
export type FilesystemLinkEntry = {
    link: string;
} & EntryMetadata;
export type FilesystemEntry = FilesystemDirectoryEntry | FilesystemFileEntry | FilesystemLinkEntry;
export declare class Filesystem {
    private src;
    private header;
    private headerSize;
    private offset;
    private contentOffsets;
    constructor(src: string);
    getRootPath(): string;
    getHeader(): FilesystemEntry;
    getHeaderSize(): number;
    setHeader(header: FilesystemEntry, headerSize: number): void;
    searchNodeFromDirectory(p: string): FilesystemEntry;
    searchNodeFromPath(p: string): FilesystemEntry;
    insertDirectory(p: string, shouldUnpack: boolean): Record<string, FilesystemEntry>;
    insertFile(p: string, streamGenerator: () => NodeJS.ReadableStream, shouldUnpack: boolean, file: CrawledFileType, options?: {
        transform?: (filePath: string) => NodeJS.ReadWriteStream | void;
        /**
         * Set when the file content comes from a stream rather than a file on
         * disk at `p`. In that case `p` is only the destination path inside the
         * archive, so integrity must be computed from the stream.
         */
        fromStream?: boolean;
    }): Promise<boolean>;
    /**
     * Fills in a file entry and reserves the region of the archive that holds its
     * contents, growing the archive by `size` bytes. When a file with identical
     * contents was already inserted, the entry instead points at the offset of those
     * contents and the archive is left unchanged — the caller must then skip writing
     * the contents.
     *
     * @returns whether the contents were already stored by an earlier file
     */
    private storeFileEntry;
    private insertFileAsync;
    insertLink(p: string, shouldUnpack: boolean, parentPath?: string, symlink?: string, // /var/tmp => /private/var
    src?: string): string;
    private resolveLink;
    listFiles(options?: {
        isPack: boolean;
    }): string[];
    getNode(p: string, followLinks?: boolean, depth?: number, visited?: Set<string>): FilesystemEntry;
    getFile(p: string, followLinks?: boolean, depth?: number, visited?: Set<string>): FilesystemEntry;
}
