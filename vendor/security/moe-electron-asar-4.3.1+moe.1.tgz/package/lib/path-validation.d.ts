/**
 * Validates that a resolved child path is strictly within a container directory.
 * Uses path.resolve (not realpath) so it works before paths exist on disk.
 * Throws if the resolved path escapes the container via traversal sequences.
 */
export declare function ensureWithin(container: string, filePath: string): string;
