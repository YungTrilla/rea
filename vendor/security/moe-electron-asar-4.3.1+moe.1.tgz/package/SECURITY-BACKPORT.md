Security dependency backport, 2026-11-03

Official @electron/asar4.3.1 archive SHA512 6pI64z/tMSBkUTZLQFYhs2YiB7fS9sKA6gy7/2nH1Ju7GGwT32UPsj4Mxsws5NMmtR6C0zYdXVxEU/rGqJRCJA==. Source https://github.com/electron/asar ; npm archive electron-asar-4.3.1.tgz.

All original lib/, bin/, maps, declarations, README and MIT license bytes unchanged. This scoped runtime distribution changes only metadata and adds this provenance. Exact glob14.0.2 and minimatch11.0.4 address GHSA-3g3m-2fjr-6pw4 and GHSA-g3hv-75wg-m249. Existing glob Promise enumeration/options and named minimatch matching API remain the consumed contract; CLI archive pack/list/extract and unpack-pattern behavior are acceptance targets. Node floor22.12 remains. Test/development scripts referred to inputs absent from the published archive and are omitted; no upstream test source is altered. CLI name asar preserved explicitly. No Windows/macOS signed app packaging claim before corresponding hardware acceptance.
