# Scoped Frida 17.23.2 dependency metadata backport

Identity: @moe/frida@17.23.2 (first immutable scoped build).
Original input: https://registry.npmjs.org/frida/-/frida-17.23.2.tgz
Original integrity: sha512-gRCmmTUFdEILyHRN1b66erRoXafwsfWTqXyoBBqkSCFX0Ue7Jhvs/KhA3JO0XrgITNlPd91QAGsFvWzh0mhVgg==

Only package name and minimatch dependency change; minimatch is exactly
11.0.4. Every original runtime, declaration, installer, script, build input,
mode, license metadata and inherited test/fixture byte is retained. No
host frida_binding.node is included, no script/test/native code executed
while producing this archive, and no test changed or deleted.

Actual matcher: build/src/frida.js imports Minimatch and Device.getProcess
constructs new Minimatch(name.toLowerCase()), then calls match() on names.
Official scripts/install.js delegates to prebuild-install and make; it
contains no direct matcher call. Both public matcher operations survive.

Native package version stays17.23.2: prebuild-install7.1.3 strips @scope/
for the artifact filename, so default release URL and platform/NAPI8
selection are unchanged. Meson version parsing and source fallback are
unchanged. Package-specific mirror environment prefixes derive from the
scoped name; users of custom mirrors must configure the scoped package.
The upstream Node>=16 declaration is retained; both minimatch10 and11
already require Node20 or>=22. This candidate targets REA Node24; it does
not newly certify Node16/18 or native instrumentation acceptance.

Scoped identity and integrity identify the local metadata fork; audit
disappearance alone is not a security or native acceptance claim.
